//
//  SceneDelegate.h
//  Nasa_images
//
//  Created by CHRISTIAN BEYNIS on 8/6/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

