//
//  DetailVc.h
//  Nasa_images
//
//  Created by CHRISTIAN BEYNIS on 8/7/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailVc : NSObject

@end

NS_ASSUME_NONNULL_END
