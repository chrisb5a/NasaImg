//
//  DetailVc.m
//  Nasa_images
//
//  Created by CHRISTIAN BEYNIS on 8/7/22.
//

#import "DetailVc.h"
#import "NetworkManager.h"
#import "NasaImg.h"

@implementation DetailVc

@end
